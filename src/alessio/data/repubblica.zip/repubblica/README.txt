GUIDA AI DATASET

- repubblica_df.csv: il dataset contenente tutti gli articoli scaricati da Repubblica così come sono
- repubblica_clean_not-screened.json: il dataset con gli articoli "ripuliti" da testo non UTF-8
- repubblica_clean_en_not-screened.json: il dataset di cui sopra tradotto in inglese
- repubblica_emotions_not-screened.json: il dataset derivato da "en_not-screened" con l'aggiunta di tante colonne quante sono le emozioni riconosciute dal modello "xlm-roberta-base"

I dataset "screened" sono analoghi ai precedenti, ma gli articoli sono stati filtrati in maniera aggressiva per essere sicuri che rimanessero solo articoli veramente pertinenti con il tema della scherma italiana. Il fatto è che le query eseguibili nell'archivio di Repubblica sono di tipo lessicale e perciò testare i termini "scherma", "Italia", "Olimpiadi" potrebbe non dare sempre risultati pertinenti.